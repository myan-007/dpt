from collections import Counter

class __Rule:
   ''' Decorator to handle preprocessing for rules '''

   def __init__(self, f):
      self.fun = f
      self.matches = []
      self.chunks = []

   def __call__(self, text):
      # Use default value as function will only be called indirectly
      self.chunk(text, checksize=self.fun.__defaults__[0])
      for tg in self.chunks:
         if self.fun(tg):
            self.matches.append(tg)
      tmp = self.matches
      self.reset()
      return tmp

   def chunk(self, text, checksize):
      ''' split into <checksize> sized token groups '''
      for i in range(0, len(text.split())-(checksize-1)):
         self.chunks.append(tuple(text.split()[i:i+checksize]))

   def reset(self):
      self.matches = []
      self.chunks = []
      self.counter = 0



class Rule(__Rule):
   def __init__(self, f):
      super().__init__(f)

   def __call__(self, text):
      # Use default value as function will only be called indirectly
      self.chunk(text, checksize=self.fun.__defaults__[0])
      for tg in self.chunks:
         if self.fun(tg):
            self.matches.append(tuple(self.fun(tg)))
      tmp = self.matches
      self.reset()
      return tmp


"""
def applyRules(listOfFunctions, text, fit='one'):
   ''' Applies all rules and keeps either hits matching all rules (all) or
       matching at least one rule (one).
       Returns a list of matching tuples '''
   if fit == 'all':
      mset = Counter()
      for fun in listOfFunctions:
         if fun(text):
            mset.update(set(fun(text)))
      try:
         if mset.most_common(1)[0][1] == len(listOfFunctions):
            return [t[0] for t in mset.most_common(1)]
      except IndexError:
         return []

   elif fit == 'one':
      matches = []
      for fun in listOfFunctions:
         matches.extend(fun(text))

      return matches

   else:
      raise NotImplementedError

   return []
"""


def applyRules(listOfFunctions, text, fit='one'):
   ''' Applies all rules and keeps either hits matching all
       context rules (all) or matching at least one rule (one).
       Returns a list of matching tuples '''
   matches = set()
   if fit == 'all':
      for fun in listOfFunctions:
         if matches == set():
            matches = set(fun(text))
         else:
            matches &= set(fun(text))

   elif fit == 'one':
      for fun in listOfFunctions:
         matches.update(set(fun(text)))

   else:
      raise NotImplementedError

   return list(matches)
