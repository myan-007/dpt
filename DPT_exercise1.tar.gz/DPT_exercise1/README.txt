Alexander Fraser
2024-04-22


Exercise 1 - Rule-based Extraction
==================================

You will need Linux to work with this system.

(Mac might work, but you will have some problems with tools that are not installed, just install them!)

--

To expand under Linux:

% tar xvf DPT_exercise1.tar.gz

Then look in the subdirectory for slides.pdf and get started.

Getting an F1 of 30% (0.30) should be fairly easy, it is very possible to get much better scores with about an hour of work.

--

If you get an error mentioning colordiff, then type:

% colordiff

and follow the instructions to install it.

(On Mac: brew install colordiff) (IMPORTANT: it usually recommends you do "brew upgrade", DO NOT DO THIS, it usually takes forever and is unnecessary)
