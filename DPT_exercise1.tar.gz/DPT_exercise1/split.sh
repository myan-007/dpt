#!/bin/bash

# Create train, dev, devtest
for a in `cat TRAINLIST`;
do
   mv $a ./sa-tagged/train/
done

for a in `cat DEVLIST`;
do
   mv $a ./sa-tagged/dev/
done

for a in `cat TESTLIST`;
do
    mv $a ./sa-tagged/test/
done
