#!/usr/bin/python3

import re
import argparse

argP = argparse.ArgumentParser(description="Automatic Evaluation of CMU Seminar IE Exercise")
argP.add_argument("-g", "--gold", nargs='+', action="store")
argP.add_argument("-e", "--eval", nargs='+', action="store")

loc_re = re.compile('<location>(.+?)</location>')

def main():
   args = argP.parse_args()

   all_locations_gold = set()
   num_locations_gold = 0
   all_locations_eval = []

   for f in args.gold:
      with open(f, 'r') as fh:
         raw = fh.read()
         # clean up sentence annotations in locations
         loc_local = [re.sub(re.compile('<.+?>'), '', elem) for
                      elem in  loc_re.findall(raw)]
         num_locations_gold += len(loc_local)
         all_locations_gold.update(loc_local)

   for f in args.eval:
      with open(f, 'r') as fh:
         raw = fh.read()
         loc_local = loc_re.findall(raw)
         all_locations_eval.extend(loc_local)

   true_pos  = [f for f in all_locations_eval if f in all_locations_gold]
   false_pos = [f for f in all_locations_eval if f not in all_locations_gold]

   num_true_pos  = len(true_pos)
   num_false_pos = len(false_pos)
   num_false_neg = num_locations_gold - num_true_pos
   try:
      precision = num_true_pos / (num_true_pos + num_false_pos)
      recall = num_true_pos / (num_true_pos + num_false_neg)
   except ZeroDivisionError:
      precision = 0.00001
      recall = 0.00001

   f1 = 2 * (precision * recall) / (precision + recall)

   print('true positives:', num_true_pos)
   print('false positives:', num_false_pos)
   print('false negatives:', num_false_neg)
   print('all:', num_locations_gold)

   print('Precision:', precision)
   print('Recall:', recall)
   print('F1:', f1)




if __name__ == "__main__": main()
