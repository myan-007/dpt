#!/usr/bin/python3

import re
import os
import string
import argparse
from Rule import Rule, applyRules

argP = argparse.ArgumentParser(description="Apply extraction rules to files")
argP.add_argument("files", nargs='+', action="store")
argP.add_argument("-d", "--directory", action="store")
argP.add_argument("-s", "--stdout", action="store_true")
argP.add_argument("-v", "--verbose", action="store_true")


######################### Rules ###########################

@Rule
def hasRoom(tokenGroup, checksize=2):
   if tokenGroup[0].lower().strip() == 'room':
      return tokenGroup
   return []


@Rule
def startsWithIn(tokenGroup, checksize=3):
   if tokenGroup[0] == 'in':
      return tokenGroup[1:]
   return []



def main():
   args = argP.parse_args()

   # List of functions that should be applied
   # XXX: Register your new rules here
   rules = [
            hasRoom,
            startsWithIn,
           ]

   # Collection of findings as a set to avoid duplicate tagging
   # If uncommented here the extracted locations will carry over file
   # boundaries
   # extracted_locations = set()


   # Apply the rules on each file and collect locations
   for f in args.files:

      # Collection of findings as a set to avoid duplicate tagging
      extracted_locations = set()

      text = ''
      with open(f) as fh:
         text = fh.read()
         # If you want one set of rules to apply completely and one set to
         # apply if at least one rule matches then use two lists of rules
         extracted_local1 = applyRules(rules, text, fit='one')
         extracted_locations |= set(extracted_local1)

      if args.verbose:
         for loc in extracted_locations:
            print('Found:', loc)

      # Reinsert tags
      for loc in extracted_locations:
         text = text.replace(' '.join(loc), '<location>' + ' '.join(loc)
         + '</location>')
      filename = os.path.basename(f)

      if args.stdout:
         print(text)
      else:
         with open(os.path.join(args.directory, filename), 'w+') as fh:
            print(text, file=fh)


if __name__ == "__main__": main()
