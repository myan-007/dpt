#!/usr/bin/python3

import re
import sys


def main():
   ''' Returns file content in a single string without markup '''

   # Regex to match all tags but locations
   r = re.compile('</?(?!/?location).+?>')
   with open(sys.argv[1]) as fh:
      raw = fh.read()
      print(re.sub(r, ' ', raw))



if __name__ == "__main__": main()
